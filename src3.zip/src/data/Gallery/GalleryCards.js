export const GalleryImages = [
    {
        id: 1,
        img: '../src/assets/portada.png',
        alt: 'Animal 1',
    },
    {
        id: 2,
        img: '../src/assets/portada2.jpg',
        alt: 'Animal 2',
    },
    {
        id: 3,
        img: '../src/assets/hola.webp',
        alt: 'Animal 3',
    },
    {
        id: 4,
        img: '../src/assets/hola2.jpg',
        alt: 'Animal 4',
    },
    {
        id: 5,
        img: '../src/assets/hola3.jpg',
        alt: 'Animal 5',
    },
    {
        id: 6,
        img: '../src/assets/hola4.jpg',
        alt: 'Animal 6',
    },
    {
        id: 7,
        img: '../src/assets/hola5.jpg',
        alt: 'Animal 7',
    },
    {
        id: 8,
        img: '../src/assets/hola6.jpg',
        alt: 'Animal 8',
    },
    {
        id: 9,
        img: '../src/assets/hola7.webp',
        alt: 'Animal 9',
    },
    {
        id: 10,
        img: '../src/assets/hola8.jpg',
        alt: 'Animal 10',
    },
    {
        id: 11,
        img: '../src/assets/hola9.jpg',
        alt: 'Animal 11',
    },
    {
        id: 12,
        img: '../src/assets/hola10.jpg',
        alt: 'Animal 12',
    },
    {
        id: 13,
        img: '../src/assets/hola11.avif',
        alt: 'Animal 13',
    },
    {
        id: 14,
        img: '../src/assets/dda3bc406ae4ee911199d7959bf8668d.jpg',
        alt: 'Animal 14',
    },
    {
        id: 15,
        img: '../src/assets/8e198a2393ac46c0854e9252f7c24583.jpg',
        alt: 'Animal 15',
    },
    {
        id: 16,
        img: "../src/assets/ae63ef112656420dd9310f1e2c6e6379.jpg",
        alt: "Gatico muy borracho llamado Whiskers",
    }
];
