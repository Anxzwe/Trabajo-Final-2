export const navbarLinks = [
    {
        href: "/",
        clases: "[ fa-solid  fa-house ]",
        IconText: "Inicio",
    },
    {
        href: "/contacto",
        clases: "fa-solid  fa-address-book",
        IconText: "Contacto"
    },
    {
        href: "/galeria",
        clases: "fa-solid  fa-images",
        IconText: "Galeria"
    },
    {
        href: "//",
        clases: "fa-solid  fa-users",
        IconText: "Nosotros"
    },
    {
        href: "//",
        clases: "fa-solid  fa-handshake-angle",
        IconText: "Como ayudar"
    },
    {
        href: "//",
        clases: "fa-solid  fa-arrow-right-to-bracket",
        IconText: "Iniciar sesión"
    },
];
