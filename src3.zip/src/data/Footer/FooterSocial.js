export const footerSocial =
    [
        { id: 1, href: "//instagram.com", icon: "fa-brands  fa-instagram" },
        { id: 2, href: "//x.com", icon: "fa-brands  fa-x-twitter" },
        { id: 3, href: "//whatsapp.com", icon: "fa-brands  fa-whatsapp" },
        { id: 4, href: "//facebook.com", icon: "fa-brands  fa-facebook" },
        { id: 5, href: "//youtube.com", icon: "fa-brands  fa-youtube" },
        { id: 6, href: "//linkedin.com", icon: "fa-brands  fa-linkedin" },
    ]