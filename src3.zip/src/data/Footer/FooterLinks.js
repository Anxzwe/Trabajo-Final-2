export const footerLinks = [
    { id: 1, text: "Inicio", href: "/" },
    { id: 2, text: "Contacto", href: "/contacto" },
    { id: 3, text: "Galeria", href: "/galeria" },
    { id: 4, text: "Nosotros", href: "" },
    { id: 5, text: "Como ayudar", href: "" },
    { id: 6, text: "Iniciar Sesion", href: "" }
];
