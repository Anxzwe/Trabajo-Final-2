//  Crea un id unico usando la cantidad de milisegundos desde el 1ro de enero de 1970...MOOOE especifico. JHSADJHASJKDH.

const newId = String(Date.now())
console.log(newId)