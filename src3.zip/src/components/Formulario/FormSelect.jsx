// src/components/FormSelect.jsx
import React from 'react';
import PropTypes from 'prop-types';
import '../../styles/Formulario/FormSelect.css';

export default function FormSelect({
    id,
    name,
    required,
    optiontext,
    options,
    value,
    onChange,
}) {
    return (
        <select
            id={id}
            name={name}
            className="formulario__select"
            required={required}
            value={value}
            onChange={onChange}
        >
            {/* placeholder oculto, pero seleccionado al inicio */}
            <option value="" disabled hidden>
                {optiontext}
            </option>
            {options.map(opt => (
                <option key={opt.value} value={opt.value}>
                    {opt.label}
                </option>
            ))}
        </select>
    );
}

FormSelect.propTypes = {
    id: PropTypes.string.isRequired,
    name: PropTypes.string.isRequired,
    required: PropTypes.bool,
    optiontext: PropTypes.string.isRequired,
    options: PropTypes.arrayOf(
        PropTypes.shape({
            value: PropTypes.string.isRequired,
            label: PropTypes.string.isRequired,
        })
    ).isRequired,
    value: PropTypes.string,
    onChange: PropTypes.func,
};

FormSelect.defaultProps = {
    required: false,
    value: '',
    onChange: () => { },
};
