// src/components/Formulario.jsx
import React, { useState } from 'react';
import '../../styles/Formulario/Formulario.css';
import FormInput from './FormInput';
import FormLabel from './FormLabel';
import FormSelect from './FormSelect';
import FormArea from './FormArea';

export default function Formulario() {
    const initialState = {
        name: '',
        surname: '',
        age: '',
        genre: '',
        email: '',
        tel: '',
        feedback: '',
        notify: false,
    };
    const [formData, setFormData] = useState(initialState);

    const handleChange = e => {
        const { name, type, value, checked } = e.target;
        setFormData(prev => ({
            ...prev,
            [name]: type === 'checkbox' ? checked : value,
        }));
    };

    const handleSubmit = e => {
        e.preventDefault();
        console.log('Datos del formulario:', formData);
    };

    const handleReset = () => setFormData(initialState);

    return (
        <section className="gradient-bc">
            <main>
                <form
                    className="formulario"
                    onSubmit={handleSubmit}
                    onReset={handleReset}
                >
                    {/* Información Básica */}
                    <fieldset className="formulario__field">
                        <legend className="formulario__legend">INFORMACIÓN BÁSICA</legend>

                        <FormLabel labelFor="name" text="Nombre" />
                        <FormInput
                            name="name"
                            id="name"
                            classN="formulario__input"
                            type="text"
                            placeholder="Nombre"
                            required
                            value={formData.name}
                            onChange={handleChange}
                        />

                        <FormLabel labelFor="surname" text="Apellido" />
                        <FormInput
                            name="surname"
                            id="surname"
                            classN="formulario__input"
                            type="text"
                            placeholder="Apellido"
                            required
                            value={formData.surname}
                            onChange={handleChange}
                        />

                        <FormLabel labelFor="age" text="Edad" />
                        <FormInput
                            name="age"
                            id="age"
                            classN="formulario__input"
                            type="number"
                            placeholder="21"
                            required
                            value={formData.age}
                            onChange={handleChange}
                        />

                        <FormLabel labelFor="genre" text="Género" />
                        <FormSelect
                            id="genre"
                            name="genre"
                            classN="formulario__select"
                            optiontext="Selecciona tu género"
                            required
                            value={formData.genre}
                            onChange={handleChange}
                            options={[
                                { value: 'hombre', label: 'Hombre' },
                                { value: 'mujer', label: 'Mujer' },
                                { value: 'otro', label: 'Otro' },
                            ]}
                        />
                    </fieldset>

                    {/* Información de Contacto */}
                    <fieldset className="formulario__field">
                        <legend className="formulario__legend">INFORMACIÓN DE CONTACTO</legend>

                        <FormLabel labelFor="email" text="Email" />
                        <FormInput
                            name="email"
                            id="email"
                            classN="formulario__input"
                            type="email"
                            placeholder="ejemplo@gmail.com"
                            required
                            value={formData.email}
                            onChange={handleChange}
                        />

                        <FormLabel labelFor="tel" text="Teléfono" />
                        <FormInput
                            name="tel"
                            id="tel"
                            classN="formulario__input"
                            type="tel"
                            placeholder="1594835114"
                            required
                            value={formData.tel}
                            onChange={handleChange}
                        />
                    </fieldset>

                    {/* Feedback */}
                    <FormLabel
                        labelFor="formTextarea"
                        classN="formulario__label--design"
                        text="Feedback"
                    />
                    <FormArea
                        id="formTextarea"
                        name="feedback"
                        rows={5}
                        maxLength={10000}
                        text="Déjanos un mensaje..."
                        value={formData.feedback}
                        onChange={handleChange}

                    />

                    {/* Notificaciones */}
                    <div className="formulario__container1">
                        <FormLabel
                            labelFor="notify"
                            classN="formulario__label--design"
                            text="Enviarme notificaciones sobre nuevas adopciones"
                        />
                        <FormInput
                            name="notify"
                            id="notify"
                            classN="formulario__input-checkbox"
                            type="checkbox"
                            checked={formData.notify}
                            onChange={handleChange}
                        />
                    </div>

                    {/* Botones */}
                    <div className="formulario__container2">
                        <FormInput
                            type="submit"
                            id="submitBtn"
                            name="submitBtn"
                            classN="formulario__button"
                            value="Enviar"
                        />
                        <FormInput
                            type="reset"
                            id="resetBtn"
                            name="resetBtn"
                            classN="formulario__button"
                            value="Resetear"
                        />
                    </div>
                </form>
            </main>
        </section>
    );
}
