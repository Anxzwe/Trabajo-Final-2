// src/components/FormInput.jsx
import React from 'react';
import PropTypes from 'prop-types';
import '../../styles/Formulario/FormInput.css';

export default function FormInput({
    id,
    name,
    type,
    classN,
    placeholder,
    required,
    value,
    onChange,
    checked,
}) {
    return (
        <input
            id={id}
            name={name}
            type={type}
            className={classN}
            placeholder={placeholder}
            required={required}
            value={type === 'checkbox' ? undefined : value}
            checked={type === 'checkbox' ? checked : undefined}
            onChange={onChange}
        />
    );
}

FormInput.propTypes = {
    id: PropTypes.string.isRequired,
    name: PropTypes.string.isRequired,
    type: PropTypes.string.isRequired,
    classN: PropTypes.string,
    placeholder: PropTypes.string,
    required: PropTypes.bool,
    value: PropTypes.oneOfType([PropTypes.string, PropTypes.number]),
    onChange: PropTypes.func,
    checked: PropTypes.bool,
};

FormInput.defaultProps = {
    classN: '',
    placeholder: '',
    required: false,
    value: '',
    onChange: () => { },
    checked: false,
};
