// src/components/FormArea.jsx
import React from 'react';
import PropTypes from 'prop-types';
import '../../styles/Formulario/FormArea.css';

export default function FormArea({
    id,
    rows,
    maxLength,
    text,
    value,
    onChange,
    name
}) {
    return (
        <textarea
            id={id}
            rows={rows}
            className="formulario__textarea"
            maxLength={maxLength}
            placeholder={text}
            value={value}
            onChange={onChange}
            name={name}
        />
    );
}

FormArea.propTypes = {
    id: PropTypes.string.isRequired,
    rows: PropTypes.oneOfType([PropTypes.string, PropTypes.number]),
    maxLength: PropTypes.oneOfType([PropTypes.string, PropTypes.number]),
    text: PropTypes.string,
    value: PropTypes.string,
    onChange: PropTypes.func,
};

FormArea.defaultProps = {
    rows: 5,
    maxLength: 10000,
    text: '',
    value: '',
    onChange: () => { },
};
