// src/components/NavbarItem.jsx
import React from "react";
import { NavLink } from "react-router-dom";
import '../../styles/Navbar/NavbarLi.css';

export default function NavbarItem({ href, IconText, clases }) {
    return (
        <li className="navbar__item">
            <NavLink
                to={href}
                className={({ isActive }) =>
                    `navbar__link ${isActive ? "navbar__link--active" : ""}`
                }
                end
            >
                <i className={`${clases} navbar__icon`} />
                {IconText}
            </NavLink>
        </li>
    );
}
