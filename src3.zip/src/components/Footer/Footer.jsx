import React from "react";
import FooterList1 from "../Footer/FooterList-1";
import FooterList2 from "../Footer/FooterList-2";
import "../../styles/Footer/Footer.css";

export default function Footer() {
    return (
        <footer className='footer'>

            <nav aria-label="Enlaces a secciones y a redes">
                
                <FooterList1 />

                <p className='footer__text1'>Redes</p>

                <FooterList2 />

            </nav>

            <hr className='footer__line' />

            <p className='footer__text2'>© 2025 Nueva Esperanza</p>
        </footer>
    );
}
