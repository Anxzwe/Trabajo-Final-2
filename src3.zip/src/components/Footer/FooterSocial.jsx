import React from "react";
import "../../styles/Footer/FooterSocial.css";

export default function FooterSocial({ icon, href}) {
    return(
        <li>
            <a className='footer__link  footer__link--hover' href={href} target="blank" rel="noopener noreferrer"><i className={icon}></i></a>
        </li>
    );
}